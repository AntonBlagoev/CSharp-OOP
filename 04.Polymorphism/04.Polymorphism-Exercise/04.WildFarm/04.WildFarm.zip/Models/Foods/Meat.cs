﻿namespace WildFarm.Models.Foods
{
    internal class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
