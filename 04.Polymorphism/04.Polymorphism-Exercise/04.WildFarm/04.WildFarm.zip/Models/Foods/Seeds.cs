﻿namespace WildFarm.Models.Foods
{
    internal class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
