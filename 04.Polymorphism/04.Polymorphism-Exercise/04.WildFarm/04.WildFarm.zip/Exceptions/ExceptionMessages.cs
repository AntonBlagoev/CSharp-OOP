﻿namespace WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public const string FoodNotEatenExceptionMessage = "{0} does not eat {1}!";
    }
}
