﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
