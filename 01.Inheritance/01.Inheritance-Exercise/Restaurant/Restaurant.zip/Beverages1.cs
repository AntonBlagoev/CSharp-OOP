﻿namespace Restaurant
{
    public class Beverages
    {
    }
}