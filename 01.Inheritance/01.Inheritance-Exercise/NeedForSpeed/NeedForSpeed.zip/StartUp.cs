﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Vehicle myVehicle = new Vehicle(250, 60.0);
            //myVehicle.Drive(200);
            //System.Console.WriteLine(myVehicle.Fuel);

            //SportCar mySportCar = new SportCar(250, 60.0);
            //mySportCar.Drive(200);
            //System.Console.WriteLine(mySportCar.Fuel);


        }
    }
}
