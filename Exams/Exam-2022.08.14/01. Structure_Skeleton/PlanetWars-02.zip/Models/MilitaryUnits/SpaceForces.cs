﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class SpaceForces : MilitaryUnit
    {
        private const double UnitCost = 11.0;
        public SpaceForces() : base(UnitCost)
        {
        }
    }
}
