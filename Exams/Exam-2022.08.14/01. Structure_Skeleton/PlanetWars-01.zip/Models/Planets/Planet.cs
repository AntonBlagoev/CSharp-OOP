﻿namespace PlanetWars.Models.Planets
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using MilitaryUnits.Contracts;
    using MilitaryUnits;
    using Planets.Contracts;
    using PlanetWars.Utilities.Messages;
    using Weapons;
    using Weapons.Contracts;
    using PlanetWars.Repositories;

    public class Planet : IPlanet
    {
        private string name;
        private double budget;
        private double militaryPower;

        private UnitRepository army; // Returns  a collection of military units (UnitRepository)
        private WeaponRepository weapons; // Returns  a collection of weapons (WeaponRepository)

        public Planet(string name, double budget)
        {
            this.Name = name;
            this.Budget = budget;

            this.army= new UnitRepository();
            this.weapons = new WeaponRepository();

        }
        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlanetName);
                }
                name = value;
            }
        }

        public double Budget
        {
            get => budget;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidBudgetAmount);
                }
                budget = value;
            }
        }

        public double MilitaryPower
        {
            get => militaryPower;
            private set
            {
                double totalAmount = TotalAmount(this.army.Models, this.weapons.Models);
                militaryPower = totalAmount;
            }
        }

        private double TotalAmount(IReadOnlyCollection<IMilitaryUnit> army, IReadOnlyCollection<IWeapon> weapons)
        {
            double totalAmount = 0;
            totalAmount = army.Sum(x => x.EnduranceLevel) + weapons.Sum(x => x.DestructionLevel);
            totalAmount = Math.Round(totalAmount, 3);

            if (this.army.Models.Any(x => x.GetType().Name == nameof(AnonymousImpactUnit)))
            {
                totalAmount *= 1.3;
            }
            else if (this.army.Models.Any(x => x.GetType().Name == nameof(NuclearWeapon)))
            {
                totalAmount *= 1.45;
            }
            return totalAmount;
        }

        public IReadOnlyCollection<IMilitaryUnit> Army => this.army.Models;

        public IReadOnlyCollection<IWeapon> Weapons => this.weapons.Models;

        public void AddUnit(IMilitaryUnit unit)
        {
            this.army.AddItem(unit);
        }

        public void AddWeapon(IWeapon weapon)
        {
            this.weapons.AddItem(weapon);
        }
        public void TrainArmy()
        {
            foreach (var item in this.army.Models)
            {
                item.IncreaseEndurance();
            }
        }

        public void Spend(double amount)
        {
            if (amount > budget)
            {
                throw new InvalidOperationException(ExceptionMessages.UnsufficientBudget);
            }
            this.Budget -= amount;
        }
        public void Profit(double amount)
        {
            this.Budget += amount;
        }
        public string PlanetInfo()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Planet: {this.Name}");
            sb.AppendLine($"--Budget: {this.Budget} billion QUID");

            sb.AppendLine($"--Forces: ");
            if (army.Models.Count > 0)
            {
               sb.Append(string.Join(", ", army));
            }
            else
            {
                sb.Append("No units");
            }

            sb.AppendLine($"--Military Power: ");
            if (weapons.Models.Count > 0)
            {
                sb.Append(string.Join(", ", weapons));
            }
            else
            {
                sb.Append("No weapons");
            }

            sb.AppendLine($"--Military Power: {militaryPower}");

            return sb.ToString().TrimEnd()  ;
        }



    }
}
