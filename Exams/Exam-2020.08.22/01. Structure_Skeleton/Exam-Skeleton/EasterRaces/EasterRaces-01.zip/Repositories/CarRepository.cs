﻿namespace EasterRaces.Repositories
{
    using System.Linq;
    using Models.Cars.Contracts;
    public class CarRepository : Repository<ICar>
    {
        public override ICar GetByName(string name)
        {
            return this.GetAll().FirstOrDefault(x => x.GetType().Name == name);
        }
    }
}
