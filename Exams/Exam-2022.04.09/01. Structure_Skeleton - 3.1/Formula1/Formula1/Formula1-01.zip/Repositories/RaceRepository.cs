﻿namespace Formula1.Repositories
{
    using System.Collections.Generic;
    using System.Linq;

    using Models.Contracts;
    using Repositories.Contracts;
    public class RaceRepository : IRepository<IRace>
    {
        private readonly List<IRace> models;
        public RaceRepository()
        {
            this.models = new List<IRace>();
        }
        public IReadOnlyCollection<IRace> Models => this.models;

        public void Add(IRace model)
        {
            this.models.Add(model);
        }

        public IRace FindByName(string name)
        {
            var modelToFind = this.models.FirstOrDefault(x => x.RaceName == name);
            if (modelToFind != null)
            {
                return modelToFind;
            }

            return null; ;
        }

        public bool Remove(IRace model)
        {
            var modelToRemove = this.models.FirstOrDefault(x => x.Equals(model));
            if (modelToRemove != null)
            {
                this.models.Remove(modelToRemove);
                return true;
            }

            return false;
        }
    }
}
