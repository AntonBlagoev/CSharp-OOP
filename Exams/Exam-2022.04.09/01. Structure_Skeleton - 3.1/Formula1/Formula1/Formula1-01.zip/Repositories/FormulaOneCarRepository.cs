﻿namespace Formula1.Repositories
{
    using System.Collections.Generic;
    using System.Linq;

    using Models.Contracts;
    using Repositories.Contracts;

    public class FormulaOneCarRepository : IRepository<IFormulaOneCar>
    {
        private readonly List<IFormulaOneCar> models;

        public FormulaOneCarRepository()
        {
            this.models = new List<IFormulaOneCar>();
        }

        public IReadOnlyCollection<IFormulaOneCar> Models => this.models;

        public void Add(IFormulaOneCar model)
        {
            this.models.Add(model);
        }

        public IFormulaOneCar FindByName(string name)
        {
            var modelToFind = this.models.FirstOrDefault(x => x.Model == name);
            if (modelToFind != null)
            {
                return modelToFind;
            }

            return null;
        }

        public bool Remove(IFormulaOneCar model)
        {
            var modelToRemove = this.models.FirstOrDefault(x => x.Equals(model));
            if (modelToRemove != null)
            {
                this.models.Remove(modelToRemove);
                return true;
            }

            return false;
        }
    }
}
