﻿namespace Gym.Models.Athletes
{
    using System;

    using Athletes.Contracts;
    using Utilities.Messages;
    public abstract class Athlete : IAthlete
    {
        private string fullName;
        private string motivation;
        private int numberOfMedals;

        protected Athlete(string fullName, string motivation, int numberOfMedals, int stamina)
        {
            this.FullName = fullName;
            this.Motivation = motivation;
            this.NumberOfMedals = numberOfMedals;
            this.Stamina = stamina;
        }

        public string FullName
        {
            get => fullName;
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidAthleteName));
                }
                fullName = value;
            }
        }
        public string Motivation
        {
            get => motivation;
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidAthleteMotivation));
                }
                motivation = value;
            }
        }
        public int NumberOfMedals
        {
            get => numberOfMedals;
            private set
            {
                if (numberOfMedals < 0)
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidAthleteMedals));
                }
                numberOfMedals = value;
            }
        }
        public int Stamina { get; protected set; }
        public abstract void Exercise();
    }
}
