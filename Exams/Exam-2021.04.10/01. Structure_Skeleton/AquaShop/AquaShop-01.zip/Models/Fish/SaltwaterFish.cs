﻿namespace AquaShop.Models.Fish
{
    public class SaltwaterFish : Fish
    {
        public SaltwaterFish(string name, string species, decimal price) : base(name, species, price)
        {
        }

        public override int Size 
        {
            get => base.Size; 
            protected set => base.Size = 5; 
        }

        public override void Eat()
        {
            this.Size += 2;
        }
    }
}
