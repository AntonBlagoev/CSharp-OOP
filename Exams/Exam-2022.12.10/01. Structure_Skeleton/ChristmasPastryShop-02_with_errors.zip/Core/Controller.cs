﻿using ChristmasPastryShop.Core.Contracts;
using ChristmasPastryShop.Models.Booths;
using ChristmasPastryShop.Models.Cocktails;
using ChristmasPastryShop.Models.Cocktails.Contracts;
using ChristmasPastryShop.Models.Delicacies;
using ChristmasPastryShop.Models.Delicacies.Contracts;
using ChristmasPastryShop.Repositories;
using ChristmasPastryShop.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace ChristmasPastryShop.Core
{
    public class Controller : IController
    {
        private BoothRepository	booths;

        public Controller()
        {
            this.booths = new BoothRepository();
        }
        public string AddBooth(int capacity)
        {
            int boothID = this.booths.Models.Count + 1;
            Booth booth = new Booth(boothID, capacity);
            booths.AddModel(booth);

            return string.Format(OutputMessages.NewBoothAdded, boothID, capacity);
        }
        public string AddDelicacy(int boothId, string delicacyTypeName, string delicacyName)
        {
            var booth = booths.Models.FirstOrDefault(x => x.BoothId == boothId);
            var delicacy = booth.DelicacyMenu.Models.FirstOrDefault(x => x.Name == delicacyName);

            if (delicacyTypeName != nameof(Gingerbread) || delicacyTypeName != nameof(Stolen))
            {
                return string.Format(OutputMessages.InvalidDelicacyType, delicacyTypeName);
            }
            else if (delicacy != null)
            {
                return string.Format(OutputMessages.DelicacyAlreadyAdded, delicacyTypeName);
            }
            else
            {
                if (delicacyTypeName == nameof(Gingerbread))
                {
                    IDelicacy model = new Gingerbread(delicacyName);
                    booth.DelicacyMenu.AddModel(model);

                }
                else
                {
                    IDelicacy model = new Stolen(delicacyName);
                    booth.DelicacyMenu.AddModel(model);
                }
            }
            return string.Format(OutputMessages.NewDelicacyAdded, delicacyTypeName, delicacyName);
        }



        public string AddCocktail(int boothId, string cocktailTypeName, string cocktailName, string size)
        {
            var booth = booths.Models.FirstOrDefault(x => x.BoothId == boothId);
            var cocktail = booth.CocktailMenu.Models.FirstOrDefault(x => x.Name == cocktailName);

            if (cocktailTypeName != nameof(Hibernation) || cocktailTypeName != nameof(MulledWine))
            {
                return string.Format(OutputMessages.InvalidCocktailType, cocktailTypeName);
            }
            else if (size != "Small" || size != "Middle" || size != "Large")
            {
                return string.Format(OutputMessages.InvalidCocktailSize, size);
            }
            else if (cocktail != null && cocktail.Size == size)
            {
                return string.Format(OutputMessages.CocktailAlreadyAdded, size, cocktailName);
            }
            else
            {
                if (cocktailTypeName == nameof(Hibernation))
                {
                    ICocktail model = new Hibernation(cocktailName, size);
                    booth.CocktailMenu.AddModel(model);

                }
                else
                {
                    ICocktail model = new MulledWine(cocktailName, size);
                    booth.CocktailMenu.AddModel(model);
                }
            }
            return string.Format(OutputMessages.NewCocktailAdded, size, cocktailName, cocktailTypeName);

        }

        public string ReserveBooth(int countOfPeople)
        {
            var orderedBooth = booths.Models.Where(x => x.IsReserved == false).OrderBy(x => x.Capacity).ThenByDescending(x => x.BoothId);

            var serchedBooth = orderedBooth.FirstOrDefault(x => x.Capacity >= countOfPeople);


            if (serchedBooth == null)
            {
                return string.Format(OutputMessages.NoAvailableBooth, countOfPeople);
            }
            else 
            {
                this.booths.Models.FirstOrDefault(x => x.BoothId == serchedBooth.BoothId).ChangeStatus();
            }

            return string.Format(OutputMessages.BoothReservedSuccessfully, countOfPeople);

        }

        public string TryOrder(int boothId, string order)
        {
            return string.Format(OutputMessages.NotRecognizedItemName, boothId, order);
        }

        public string LeaveBooth(int boothId)
        {
            return string.Format(OutputMessages.BoothIsAvailable);
        }


        public string BoothReport(int boothId)
        {



            return string.Format(OutputMessages.BoothIsAvailable);
        }





    }
}
