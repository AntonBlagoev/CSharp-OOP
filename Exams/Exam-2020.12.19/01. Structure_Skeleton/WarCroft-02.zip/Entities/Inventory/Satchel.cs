﻿namespace WarCroft.Entities.Inventory
{
    internal class Satchel : Bag
    {
        public Satchel() : base(20)
        {
        }
    }
}
