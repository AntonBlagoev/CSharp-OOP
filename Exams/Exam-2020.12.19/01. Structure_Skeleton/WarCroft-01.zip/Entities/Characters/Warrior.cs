﻿namespace WarCroft.Entities.Characters
{
    using System;

    using Characters.Contracts;
    using Inventory;
    using WarCroft.Constants;

    public class Warrior : Character, IAttacker
    {
        public Warrior(string name) : base(name, 100, 50, 40, new Satchel())
        {
            this.BaseHealth = 100;
            this.BaseArmor = 50;
        }

        public void Attack(Character character)
        {
            if (this.IsAlive && character.IsAlive)
            {
                if (this.Name == character.Name)
                {
                    throw new InvalidOperationException(string.Format(ExceptionMessages.CharacterAttacksSelf));

                }
                var hitPointsOFAttacker = this.AbilityPoints;
                character.TakeDamage(hitPointsOFAttacker);
            }
        }
    }
}


