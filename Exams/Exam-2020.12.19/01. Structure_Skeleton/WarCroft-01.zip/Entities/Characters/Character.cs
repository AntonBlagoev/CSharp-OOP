﻿using System;
using System.Collections.Concurrent;
using WarCroft.Constants;
using WarCroft.Entities.Inventory;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
        // TODO: Implement the rest of the class.

        private string name;
        private double health;
        private double armor;

        protected Character(string name, double health, double armor, double abilityPoints, Bag bag)
        {
            Name = name;
            Health = health;
            Armor = armor;
            AbilityPoints = abilityPoints;
            this.bag = bag;
        }

        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.CharacterNameInvalid));
                };
                name = value;
            }
        }
        public double BaseHealth { get; protected set; }

        public double Health
        {
            get => health;
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                if (value > this.BaseHealth)
                {
                    value = this.BaseHealth;
                }
                health = value;
            }
        }

        public double BaseArmor { get; protected set; }

        public double Armor
        {
            get => armor;
            private set
            {
                if (value < 0)
                {
                    value = 0;
                }
                armor = value;
            }
        }
        public double AbilityPoints { get; private set; }

        public Bag bag { get; private set; }

        public bool IsAlive { get; set; } = true;

        protected void EnsureAlive()
        {
            if (!this.IsAlive)
            {
                throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
            }
        }

        public void TakeDamage(double hitPoints)
        {
            this.Armor -= hitPoints;
            hitPoints -= this.Armor;
            
            if (hitPoints > 0)
            {
                this.Health-= hitPoints;
            }

            if (this.Health == 0)
            {
                this.IsAlive = false;
            }
        }

        public void UseItem(Item item)
        {
            if (this.IsAlive)
            {
                // TODO
            }
        }
    }
}