﻿namespace AuthorProblem //For Judge have to change the name of csproj file in the Zip file to AuthorProblem.csproj
{
    [Author("Ventsi")]
    public class StartUp
    {
        [Author("Gosho")]
        static void Main(string[] args)
        {

        }
    }
}