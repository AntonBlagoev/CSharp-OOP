﻿namespace BorderControl.Models.Interfaces
{
    public interface IBorderControl
    {
        string Id { get; }
    }
}
