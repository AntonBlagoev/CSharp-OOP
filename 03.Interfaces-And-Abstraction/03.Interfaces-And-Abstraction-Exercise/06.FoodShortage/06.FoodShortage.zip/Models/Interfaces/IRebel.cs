﻿namespace FoodShortage.Models.Interfaces
{
    public interface IRebel
    {
        string Name { get; }
        int Age { get; }
        string Group { get; }
    }
}
