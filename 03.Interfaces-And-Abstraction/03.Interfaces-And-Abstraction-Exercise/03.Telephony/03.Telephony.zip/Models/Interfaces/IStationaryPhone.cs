﻿namespace Telephony.Models.Interfaces
{
    public interface IStationaryPhone
    {
        public string Call(string phoneNumber);
    }
}
