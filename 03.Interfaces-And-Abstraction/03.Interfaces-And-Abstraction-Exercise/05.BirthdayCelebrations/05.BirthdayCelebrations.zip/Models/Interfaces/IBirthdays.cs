﻿namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IBirthdays
    {
        string Birthdate { get; }
    }
}
